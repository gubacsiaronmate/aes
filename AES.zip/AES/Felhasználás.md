# Felhasználói utasítás

1. Sablon (template):  
    `kolibriemailer/src/main/resources/templates` mappában található az email sablonja `emailTemplate.html` néven. Emellett a mappában megtalálható a sablon stilisztikai formázásához szükséges `style.css` CSS fájl is.
2. Emailek időzítése:  
   A `kolibriemailer/src/main/resources` mappában található `timer.properties` fáljban van lehetőség két email elküldése közti idő megváltoztatására. **Fontos hogy csak a számot változtassuk a hozzátartozó szöveges nevét semmiképpen sem!**
3. Parancsikon:  
   Egyszerűbb használat érdekében érdemes egy parancsikont létrehozni a megfelelő `.exe` fájlhoz. A közpönti `.exe` fájl elérési útja: `AES\Automatic Email Sender\bin\Release\net8.0\Automatic Email Sender.exe`

---

Bármilyen kérdés felmerülése esetén elérhető vagyok:  
 - hétköznapokon:
   - Messengeren 6:00 és 22:00 között _(ajánlott elérhetőség)_
   - +36 30 379 0774 vagy +36 70 747 5861 telefonszámokon 15:00 és 22:00 között
   - g.aronmate16@gmail.com email címen 6:00 és 22:00 között
 - hétvégén:
   - Messengeren 12:00 és 23:00 között _(ajánlott elérhetőség)_
   - +36 30 379 0774 vagy +36 70 747 5861 telefonszámokon 12:00 és 20:00 között
   - g.aronmate16@gmail.com email címen 12:00 és 23:00 között