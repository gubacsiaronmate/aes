rootProject.name = "kolibriemailer"
