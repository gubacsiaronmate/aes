import './vaadin-featureflags.js';

import './index';

import './vaadin-react.js';
import 'Frontend/generated/jar-resources/vaadin-dev-tools/vaadin-dev-tools.js';
