package util

class CustomException(message:String): Exception(message)

fun log(msg:Any, includeSuffix:Boolean = true, prefix:String = "\n\n\n", suffix:String = "\n\n\n") {
    if (includeSuffix) {
        println("$prefix${Kolor.foreground(msg.toString(), Color.BLACK).toString().lightWhiteBackground()}$suffix")
    } else {
        println("$prefix${Kolor.foreground(msg.toString(), Color.BLACK).toString().lightWhiteBackground()}")
    }
}