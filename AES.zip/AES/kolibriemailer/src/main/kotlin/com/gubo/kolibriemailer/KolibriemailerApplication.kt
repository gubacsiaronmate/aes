package com.gubo.kolibriemailer

import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.time.delay
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.web.bind.annotation.RestController
import util.log
import java.time.Duration
import java.util.*

@SpringBootApplication
class KolibriemailerApplication

private var DESKTOP = "${System.getProperty("user.home")}/Desktop"
private var STATIC = "$DESKTOP/AES/kolibriemailer/src/main/resources/static"

private const val TIMER_CONFIG = "/timer.properties"

object PropertiesReader {
    private val properties = Properties()

    init {
        val inStream = javaClass.getResourceAsStream(TIMER_CONFIG)
        log(inStream?.toString() ?: "resource stream is null")
        properties.load(inStream)
    }

    fun getProperty(key: String): String? = properties.getProperty(key)
}

fun main(args: Array<String>) {
    val context = SpringApplication.run(KolibriemailerApplication::class.java, *args)
    val emailSender = context.getBean(EmailSender::class.java)

    val timeDelay = PropertiesReader.getProperty("app.timer.delay")!!.toInt()

    emailSender.mainEmailSenderFunction(timeDelay)
}

@RestController
class EmailSender {
    @Autowired lateinit var emailSenderService: EmailSenderService

    fun mainEmailSenderFunction(timeOut: Int) = runBlocking {

        val data = readData("$STATIC/emailer.txt")
        launch {
            data.forEach { (companyName, companyEmailAddress) ->
                log("companyName: $companyName, companyEmailAddress: $companyEmailAddress")
                val success = emailSenderService.sendEmail(companyName, companyEmailAddress)
                if (success) println("Successfully sent email to $companyEmailAddress")
                else println("Failed to send email to $companyEmailAddress")
                delay(Duration.ofMinutes(timeOut.toLong()))
            }
        }
    }
}

