package com.gubo.kolibriemailer

import java.io.File

fun readData(FILEPATH: String): Map<String, String> =
    File(FILEPATH)
        .inputStream()
        .bufferedReader()
        .lineSequence()
        .associate { line -> line
            .split(";")
            .let { Pair(it[0], it[1]) } }
        .toMutableMap()
