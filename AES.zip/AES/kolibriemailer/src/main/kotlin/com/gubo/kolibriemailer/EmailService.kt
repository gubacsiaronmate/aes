package com.gubo.kolibriemailer

import util.log
import jakarta.mail.internet.MimeMessage
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.context.annotation.Configuration
import org.springframework.mail.javamail.JavaMailSender
import org.springframework.mail.javamail.JavaMailSenderImpl
import org.springframework.mail.javamail.MimeMessageHelper
import org.springframework.stereotype.Service
import org.thymeleaf.context.Context
import org.thymeleaf.spring6.SpringTemplateEngine
import java.util.*

@Configuration
class EmailConfig {
    @Autowired
    fun configure(javaMailSender: JavaMailSender): JavaMailSender {
        val mailSender = JavaMailSenderImpl()

        mailSender.host = "smtp.gmail.com"
        mailSender.port = 587
        mailSender.username = "emailerprojecttester@gmail.com"
        mailSender.password = "ktpa zugq dosf xlgt"

        val props = Properties()
        props["mail.transport.protocol"] = "smtp"
        props["mail.smtp.auth"] = "true"
        props["mail.smtp.starttls.enable"] = "true"
        mailSender.javaMailProperties = props

        return mailSender
    }
}

@Service
class EmailSenderService(
    @Autowired private val emailSender: JavaMailSender,
    @Autowired private val templateEngine: SpringTemplateEngine
) {
    fun sendEmail(name: String, targetEmail: String): Boolean {
        val message = createEmailMessage(name, targetEmail)
        try {
            emailSender.send(message)
            return true
        } catch (e: Exception) {
            // Handle exceptions here
            println("Error sending email: ${e.message}")
            return false
        }
    }

    private fun createEmailMessage(
        name: String,
        targetEmail: String
    ): MimeMessage {
        val context = Context()
        context.setVariables(mapOf(
            "recipientName" to name
        ))
        log("context.variables = ${context.variableNames}\ncontext.variables.name = ${context.getVariable("name")}")

        val content = templateEngine.process("emailTemplate", context)
        log("content = $content")

        val message = emailSender.createMimeMessage()
        MimeMessageHelper(message, true).apply {
            setFrom("emailerprojecttester@gmail.com")
            setTo(targetEmail)
            setSubject("Test Email")
            setText(content, true)
        }

        return message
    }
}
