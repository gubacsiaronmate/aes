﻿using System.Diagnostics;

namespace Automatic_Email_Sender;

class Program
{
    private static void Main(string[] args)
    {
        var excelReaderApp = $@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\AES\Email Extractor\bin\Release\net8.0-windows\Email Extractor.exe";
        var emailSenderAppDir = $@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\AES\kolibriemailer";
        
        var readerAppProcess = Process.Start(excelReaderApp);
        readerAppProcess.WaitForExit();
        
        Process p = new();
        ProcessStartInfo info = new()
        {
            FileName = "cmd.exe",
            RedirectStandardInput = true,
            UseShellExecute = false
        };

        p.StartInfo = info;
        p.Start();

        using (var sw = p.StandardInput)
        {
            if (sw.BaseStream.CanWrite)
            {
                sw.WriteLine($"cd {emailSenderAppDir}");
                sw.WriteLine("gradlew clean bootRun");
            }
        }
    }

    
}