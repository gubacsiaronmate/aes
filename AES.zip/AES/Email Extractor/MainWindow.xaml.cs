﻿using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Input;
using ClosedXML.Excel;
using Microsoft.Win32;

namespace Email_Extractor;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class mainWindow
{
    public mainWindow()
    {
        InitializeComponent();
    }
    

    private Dictionary<string, string> GetEmails(IXLWorksheet ws)
    {
        var nameRows = ws.Range($"A{StartingRow.Text}:A{EndingRow.Text}").Rows();
        List<string> names = [];
        names.AddRange(from row in nameRows from cell in row.Cells() select cell.GetString());
        
        var emailRows = ws.Range($"B{StartingRow.Text}:B{EndingRow.Text}").Rows();
        List<string> emails = [];
        emails.AddRange(from row in emailRows from cell in row.Cells() select cell.GetString());

        Dictionary<string, string> emailCollection = new();
        for (var i = int.Parse(StartingRow.Text) - 1; i < int.Parse(EndingRow.Text); i++)
        {
            emailCollection.Add(names[i], emails[i]);
        }

        return emailCollection;
    }

    private static void WriteToTxt(Dictionary<string, string> emailCollection)
    {
        var outputPath = $@"{Environment.GetFolderPath(Environment.SpecialFolder.Desktop)}\AES\kolibriemailer\src\main\resources\static";

        if (!File.Exists(Path.Combine(outputPath, "emailer.txt")))
            File.Create(Path.Combine(outputPath, "emailer.txt"));
        
        using var outputFile = new StreamWriter(Path.Combine(outputPath, "emailer.txt"));
        foreach (var (name, email) in emailCollection)
        {
            outputFile.WriteLine($"{name};{email}");
        }
    }
    
    private void openFile_OnClick(object _, RoutedEventArgs e)
    {
        OpenFileDialog openFileDialog = new()
        { Filter = "Excel fájlok (*.xlsx)|*.xlsx" };
        XLWorkbook? workbook = null;
        IXLWorksheet? worksheet = null;
        if (openFileDialog.ShowDialog() == true)
        {
            workbook = new XLWorkbook(openFileDialog.FileName);
            worksheet = workbook.Worksheet(1);
        }
        if (worksheet == null) throw new CustomException("Invalid .xlsx file!");
        var emailCollection = GetEmails(worksheet);
        WriteToTxt(emailCollection);
        workbook?.Dispose();
        Close();
    }

    private static readonly Regex Regex = new("[^0-9]+");
    
    private static bool IsTextAllowed(string text)
    {
        return !Regex.IsMatch(text);
    }
    
    private void FilterToOnlyNumbers_OnPreviewTextInput(object sender, TextCompositionEventArgs e)
    {
        e.Handled = !IsTextAllowed(e.Text);
    }

    // ReSharper disable once InconsistentNaming
    private class CustomException(string? message) : Exception(message);
}